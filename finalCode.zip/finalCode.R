install.packages("dplyr")
install.packages("ggplot2")
install.packages("caret")
install.packages("randomForest")

####Getting training and test data
training_data<- read.csv("train.csv")
test_data<- read.csv("test.csv")


####Observe data 
str(training_data)
head(training_data)

str(test_data)
head(test_data)


####converting Amount from factor to numeric(Training Data)
training_data$Loan_Amount_Requested<- gsub(",","",training_data$Loan_Amount_Requested)
training_data$Loan_Amount_Requested <- as.numeric(training_data$Loan_Amount_Requested)


####converting Amount from factor to numeric(Test Data)
test_data$Loan_Amount_Requested<- gsub(",","",test_data$Loan_Amount_Requested)
test_data$Loan_Amount_Requested <- as.numeric(test_data$Loan_Amount_Requested)


####taking care of Na values (Training Data)
training_data$Annual_Income <- ifelse(is.na(training_data$Annual_Income),
                                      ave(training_data$Annual_Income, FUN = function(x) mean(x, na.rm = TRUE)),
                                      training_data$Annual_Income)
training_data$Months_Since_Deliquency <- ifelse(is.na(training_data$Months_Since_Deliquency),
                                                ave(training_data$Months_Since_Deliquency, FUN = function(x) mean(x, na.rm = TRUE)),
                                                training_data$Months_Since_Deliquency)


####taking care of Na values(Test Data)
test_data$Annual_Income <- ifelse(is.na(test_data$Annual_Income),
                                  ave(test_data$Annual_Income, FUN = function(x) mean(x, na.rm = TRUE)),
                                  test_data$Annual_Income)
test_data$Months_Since_Deliquency <- ifelse(is.na(test_data$Months_Since_Deliquency),
                                            ave(test_data$Months_Since_Deliquency, FUN = function(x) mean(x, na.rm = TRUE)),
                                            test_data$Months_Since_Deliquency)


####Encoding training Data

training_data$Loan_Grade<- as.numeric(training_data$Loan_Grade)
training_data$Length_Employed<- as.numeric(training_data$Length_Employed)
training_data$Home_Owner<- as.numeric(training_data$Home_Owner)
training_data$Income_Verified<- as.numeric(training_data$Income_Verified)
training_data$Purpose_Of_Loan<- as.numeric(training_data$Purpose_Of_Loan)
training_data$Area_Type<- as.numeric(training_data$Area_Type)
training_data$Gender<- as.numeric(training_data$Gender)
training_data$Interest_Rate <- as.factor(training_data$Interest_Rate)


####Encoding Test Data

test_data$Loan_Grade<- as.numeric(test_data$Loan_Grade)
test_data$Length_Employed<- as.numeric(test_data$Length_Employed)
test_data$Home_Owner<- as.numeric(test_data$Home_Owner)
test_data$Income_Verified<- as.numeric(test_data$Income_Verified)
test_data$Purpose_Of_Loan<- as.numeric(test_data$Purpose_Of_Loan)
test_data$Area_Type<- as.numeric(test_data$Area_Type)
test_data$Gender<- as.numeric(test_data$Gender)


####fitting RandomForest Model

library(randomForest)
set.seed(88)
rf<- randomForest(Interest_Rate~Loan_Amount_Requested+Loan_Grade+
                                Length_Employed+Home_Owner+Annual_Income+         
                                Income_Verified+Purpose_Of_Loan+Debt_To_Income+
                                Inquiries_Last_6Mo+Total_Accounts+Area_Type+Gender
                               ,data=training_data)
print(rf)

####predict and confusion matrix for training dat
library(caret)
pred_training<- predict(rf,training_data)
confusionMatrix(pred_training, training_data$Interest_Rate)


####Predicting for Test Data
pred_testing <- predict(rf,test_data)

####Saving result to CSV
result<- cbind(test_data$Loan_ID,pred_testing)
colnames(result)<- c('Loan_ID','Interest_Rate')

write.csv(result, file='solution.csv',row.names=FALSE)


